import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
	    System.out.println("solve the equation");
	    System.out.println("first :  choice the digit of your chalenge" );
	    System.out.println(" for one digit : type 1  ");
	    System.out.println(" for two digit : type 2  ");
	    System.out.println(" for three digit : type 3  ");
	    Scanner input = new Scanner(System.in);
	    int a = input.nextInt();
	    
	    if (a==1) {
	double x=(int)(Math.random()*10);
	double y=(int)(Math.random()*10);
	System.out.println("x = "+x);
	System.out.println("y = "+y);
	System.out.println("enter x+y value");
    double z = input.nextDouble();
	if (z == x+y) {System.out.println("your answer is true");}
	else {System.out.println("wrong answer");};
	}
	else if (a==2) {
	    	double x=(int)(Math.random()*100);
	double y=(int)(Math.random()*100);
	System.out.println("x = "+x);
	System.out.println("y = "+y);
	System.out.println("enter x+y value");
    double z = input.nextDouble();
	if (z == x+y) {System.out.println("your answer is true");}
	else {System.out.println("wrong answer");};
	}
	else if (a==3)
	 {
	    	double x=(int)(Math.random()*1000);
	double y=(int)(Math.random()*1000);
	System.out.println("x = "+x);
	System.out.println("y = "+y);
	System.out.println("enter x+y value");
    double z = input.nextDouble();
	if (z == x+y) {System.out.println("your answer is true");}
	else {System.out.println("wrong answer");}
	}
	else if (a>3) {
	    System.out.println("wrong input");
	    };
	}
}